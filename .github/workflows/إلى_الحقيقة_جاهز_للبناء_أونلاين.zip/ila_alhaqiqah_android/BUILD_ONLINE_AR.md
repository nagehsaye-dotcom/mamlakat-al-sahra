# بناء APK أونلاين — إلى الحقيقة

1. ارفع مجلد المشروع إلى GitHub كمستودع جديد.
2. افتح تبويب **Actions**.
3. اختر **Build APK**.
4. اضغط **Run workflow**.
5. بعد انتهاء البناء، افتح نتيجة التشغيل وحمّل Artifact باسم:
   `ila-alhaqiqah-debug-apk`
6. فك الضغط عن الـArtifact وستجد `app-debug.apk`.

لا تحتاج إلى Android Studio على جهازك؛ عملية البناء تتم على GitHub Actions.
