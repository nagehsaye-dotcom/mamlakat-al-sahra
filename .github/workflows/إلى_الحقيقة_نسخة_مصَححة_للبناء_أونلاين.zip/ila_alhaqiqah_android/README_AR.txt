تطبيق «إلى الحقيقة»
هذه نسخة Android WebView من اللعبة التجريبية.

لإنشاء APK:
1) افتح المجلد في Android Studio.
2) انتظر مزامنة Gradle.
3) اختر Build > Build APK(s).
4) ستجد ملف APK داخل app/build/outputs/apk/debug/.

اللعبة تعمل بدون Google Play، وبيانات النسخة التجريبية محفوظة محليًا.
