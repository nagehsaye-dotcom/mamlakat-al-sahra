# إلى الحقيقة — بناء APK أونلاين بدون Android Studio

## الطريقة
1. ارفع محتويات هذا المشروع إلى مستودع GitHub.
2. افتح **Actions**.
3. اختر **Build Android APK - إلى الحقيقة**.
4. اضغط **Run workflow**.
5. انتظر حتى تظهر علامة النجاح الخضراء.
6. افتح نتيجة التشغيل ثم قسم **Artifacts**.
7. نزّل **ila-alhaqiqah-apk-v1.1**.
8. فك ضغط الـArtifact؛ ستجد `app-debug.apk`.
9. ثبّت ملف `app-debug.apk` على الهاتف.

## ملاحظة
الـArtifact الذي يظهر في GitHub يكون ZIP صغيرًا لأنه مجرد حاوية تنزيل. المهم بعد فكّه هو وجود `app-debug.apk`. إعداد البناء الجديد يتحقق أيضًا من وجود `classes.dex` و`assets/game.html` داخل الـAPK قبل رفعه.
