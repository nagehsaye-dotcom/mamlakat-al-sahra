package com.nader.ilalhaqiqah;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private WebView web;
    private TextView errorView;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.rgb(7,9,14));
        getWindow().setKeepScreenOn(true);
        buildScreen();
    }

    private void buildScreen() {
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(7,9,14));
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setLoadWithOverviewMode(false);
        s.setUseWideViewPort(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        setContentView(web);
        web.loadUrl("file:///android_asset/game.html");
    }

    private void showError() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setBackgroundColor(Color.rgb(7,9,14));
        TextView title = new TextView(this);
        title.setText("إلى الحقيقة"); title.setTextColor(Color.rgb(217,164,65)); title.setTextSize(28); title.setGravity(Gravity.CENTER);
        TextView msg = new TextView(this);
        msg.setText("تعذر تشغيل ملفات اللعبة.
اضغط إعادة المحاولة."); msg.setTextColor(Color.WHITE); msg.setTextSize(18); msg.setGravity(Gravity.CENTER);
        TextView retry = new TextView(this);
        retry.setText("إعادة المحاولة"); retry.setTextColor(Color.rgb(217,164,65)); retry.setTextSize(20); retry.setGravity(Gravity.CENTER); retry.setPadding(40,30,40,30);
        retry.setOnClickListener(v -> buildScreen());
        box.addView(title); box.addView(msg); box.addView(retry); setContentView(box);
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (web != null) { web.stopLoading(); web.destroy(); web = null; }
        super.onDestroy();
    }
}
