# إلى الحقيقة — APK V2

هذه نسخة Android محسّنة للبناء على GitHub Actions بدون Android Studio.

بعد رفع ملفات المشروع إلى المستودع وتشغيل Workflow باسم **Build إلى الحقيقة APK**، ستجد في Artifacts ملف **ila-alhaqiqah-apk-v2**. فك الضغط عنه للحصول على `app-debug.apk`.

ملاحظة: صغر حجم APK لا يعني وحده أنه غير صالح؛ WebView موجود أصلًا داخل أندرويد. المهم أن يكون الملف ناتجًا من Gradle ويحتوي على `classes.dex` و`assets/game.html` وأن يتم تثبيته وتشغيله.
