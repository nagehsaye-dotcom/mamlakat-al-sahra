using UnityEngine;
using System.Collections;

public class Unit : MonoBehaviour
{
    public bool enemy;
    public int hp = 100;
    public float speed = 2.5f;
    Renderer rend;

    public void Init(bool isEnemy, Color color)
    {
        enemy = isEnemy;
        rend = GetComponent<Renderer>();
        rend.material.color = color;
    }

    public void MoveAndAttack(Vector3 target, int damage)
    {
        StartCoroutine(AttackRoutine(target, damage));
    }

    IEnumerator AttackRoutine(Vector3 target, int damage)
    {
        Vector3 start = transform.position;
        float t=0;
        while(t<1)
        {
            t += Time.deltaTime*speed/Vector3.Distance(start,target);
            transform.position = Vector3.Lerp(start,target,Mathf.Clamp01(t));
            yield return null;
        }
        yield return new WaitForSeconds(.15f);
        hp -= damage;
        if(hp<=0)
        {
            transform.Rotate(75,0,20);
            yield return new WaitForSeconds(.2f);
            gameObject.SetActive(false);
        }
    }
}
