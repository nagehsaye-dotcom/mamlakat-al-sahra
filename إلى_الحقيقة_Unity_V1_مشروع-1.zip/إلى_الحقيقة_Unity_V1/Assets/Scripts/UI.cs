using UnityEngine;
using UnityEngine.UI;
using TMPro;

public static class UI
{
    public static TMP_Text Text(Transform parent, string text, float size, Vector2 pos, Vector2 dims)
    {
        var go = new GameObject("Text");
        go.transform.SetParent(parent, false);
        var rt = go.AddComponent<RectTransform>();
        rt.anchoredPosition = pos;
        rt.sizeDelta = dims;
        var t = go.AddComponent<TextMeshProUGUI>();
        t.text = text;
        t.fontSize = size;
        t.color = Color.white;
        t.enableWordWrapping = true;
        return t;
    }

    public static Button Button(Transform parent, string label, Vector2 pos, UnityEngine.Events.UnityAction action)
    {
        var go = new GameObject("Button_" + label);
        go.transform.SetParent(parent, false);
        var rt = go.AddComponent<RectTransform>();
        rt.anchoredPosition = pos;
        rt.sizeDelta = new Vector2(260, 90);
        var image = go.AddComponent<Image>();
        image.color = new Color(0.08f,0.18f,0.28f,0.95f);
        var b = go.AddComponent<Button>();
        b.onClick.AddListener(action);

        var txt = Text(go.transform, label, 30, Vector2.zero, new Vector2(250,80));
        txt.alignment = TextAlignmentOptions.Center;
        return b;
    }
}
