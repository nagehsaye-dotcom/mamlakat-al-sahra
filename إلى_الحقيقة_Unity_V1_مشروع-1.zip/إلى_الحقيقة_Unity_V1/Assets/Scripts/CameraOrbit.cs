using UnityEngine;

public class CameraOrbit : MonoBehaviour
{
    Vector3 focus = new Vector3(0,0,0);
    float distance = 28f;
    float yaw = 0f;
    float pitch = 38f;

    void Update()
    {
        if (Input.touchCount == 1)
        {
            var t = Input.GetTouch(0);
            if (t.phase == TouchPhase.Moved)
            {
                yaw += t.deltaPosition.x * 0.12f;
                pitch -= t.deltaPosition.y * 0.08f;
                pitch = Mathf.Clamp(pitch, 20, 70);
            }
        }
        if (Input.mouseScrollDelta.y != 0)
            distance = Mathf.Clamp(distance - Input.mouseScrollDelta.y * 2f, 15, 45);

        Quaternion rot = Quaternion.Euler(pitch, yaw, 0);
        transform.position = focus + rot * new Vector3(0,0,-distance);
        transform.LookAt(focus);
    }
}
