using UnityEngine;
using System.Collections.Generic;

public class BattleManager : MonoBehaviour
{
    Transform root;
    readonly List<Unit> player = new List<Unit>();
    readonly List<Unit> enemy = new List<Unit>();

    public void BuildBattlefield()
    {
        root = new GameObject("Battlefield").transform;
        MakeGround();
        SpawnArmy(false, new Vector3(-9,0,0), 12);
        SpawnArmy(true, new Vector3(9,0,0), 12);

        var cam = Camera.main;
        cam.transform.position = new Vector3(0,18,-24);
        cam.transform.rotation = Quaternion.Euler(38,0,0);
    }

    void MakeGround()
    {
        var g = GameObject.CreatePrimitive(PrimitiveType.Plane);
        g.name="Battle Desert";
        g.transform.SetParent(root);
        g.transform.localScale = new Vector3(2.2f,1,1.2f);
        g.GetComponent<Renderer>().material.color = new Color(.36f,.27f,.17f);
    }

    void SpawnArmy(bool isEnemy, Vector3 center, int count)
    {
        for(int i=0;i<count;i++)
        {
            var go = GameObject.CreatePrimitive(i%3==0 ? PrimitiveType.Capsule : PrimitiveType.Cube);
            go.name = isEnemy ? "EnemyUnit" : "NaderUnit";
            go.transform.SetParent(root);
            float x=center.x + (i%4)*1.5f - 2.25f;
            float z=(i/4)*2f - 2.5f;
            go.transform.position = new Vector3(x,1,z);
            go.transform.localScale = new Vector3(.8f,1.5f,.8f);
            var u=go.AddComponent<Unit>();
            u.Init(isEnemy, isEnemy ? new Color(.65f,.08f,.06f) : new Color(.05f,.28f,.75f));
            (isEnemy?enemy:player).Add(u);
        }
    }

    public void ShowBattle()
    {
        if(root!=null) root.gameObject.SetActive(true);
        Camera.main.transform.position = new Vector3(0,18,-24);
        Camera.main.transform.rotation = Quaternion.Euler(38,0,0);
    }

    public void HideBattle()
    {
        if(root!=null) root.gameObject.SetActive(false);
    }

    public void CavalryAttack()
    {
        if(enemy.Count==0) return;
        for(int i=0;i<Mathf.Min(4,player.Count);i++)
        {
            if(player[i].gameObject.activeSelf && enemy[i%enemy.Count].gameObject.activeSelf)
                player[i].MoveAndAttack(enemy[i%enemy.Count].transform.position, 35);
        }
    }

    public void CommanderSkill()
    {
        int hits=0;
        foreach(var u in enemy)
        {
            if(u != null && u.gameObject.activeSelf && hits<5)
            {
                u.gameObject.SetActive(false);
                hits++;
            }
        }
    }
}
