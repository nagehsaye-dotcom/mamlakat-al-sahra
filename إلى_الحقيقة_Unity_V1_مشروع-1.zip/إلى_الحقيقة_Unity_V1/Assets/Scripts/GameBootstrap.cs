using UnityEngine;

public class GameBootstrap : MonoBehaviour
{
    public KingdomManager kingdom;
    public BattleManager battle;

    void Awake()
    {
        Application.targetFrameRate = 60;
        Screen.orientation = ScreenOrientation.LandscapeLeft;

        if (kingdom == null) kingdom = gameObject.AddComponent<KingdomManager>();
        if (battle == null) battle = gameObject.AddComponent<BattleManager>();

        kingdom.BuildKingdom();
        battle.BuildBattlefield();
        battle.HideBattle();

        BuildHUD();
    }

    void BuildHUD()
    {
        var canvasGO = new GameObject("HUD");
        var canvas = canvasGO.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        canvasGO.AddComponent<UnityEngine.UI.CanvasScaler>().uiScaleMode =
            UnityEngine.UI.CanvasScaler.ScaleMode.ScaleWithScreenSize;
        canvasGO.GetComponent<UnityEngine.UI.CanvasScaler>().referenceResolution = new Vector2(1920,1080);
        canvasGO.AddComponent<UnityEngine.UI.GraphicRaycaster>();

        var title = UI.Text(canvasGO.transform, "إلى الحقيقة", 54, new Vector2(0, 470), new Vector2(700,100));
        title.alignment = TMPro.TextAlignmentOptions.Center;
        title.fontStyle = TMPro.FontStyles.Bold;

        var info = UI.Text(canvasGO.transform, "القائد نادر  •  الذهب: 5000  •  الطعام: 3000  •  الخشب: 2000", 28,
            new Vector2(-520, 385), new Vector2(1000,70));

        var kingdomBtn = UI.Button(canvasGO.transform, "المملكة", new Vector2(-650,-430), () => {
            kingdom.ShowKingdom();
            battle.HideBattle();
        });
        var battleBtn = UI.Button(canvasGO.transform, "المعركة", new Vector2(-350,-430), () => {
            kingdom.HideKingdom();
            battle.ShowBattle();
        });

        UI.Button(canvasGO.transform, "هجوم الفرسان", new Vector2(250,-430), () => battle.CavalryAttack());
        UI.Button(canvasGO.transform, "مهارة القائد", new Vector2(600,-430), () => battle.CommanderSkill());

        UI.Text(canvasGO.transform,
            "نسخة Unity V1 — مملكة ثلاثية الأبعاد قابلة للتوسع\nابنِ مملكتك • درّب جيشك • ابدأ المعركة",
            30, new Vector2(0,-330), new Vector2(900,130)).alignment = TMPro.TextAlignmentOptions.Center;
    }
}
