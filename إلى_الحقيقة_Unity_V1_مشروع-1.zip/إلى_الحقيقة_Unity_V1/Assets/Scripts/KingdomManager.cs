using UnityEngine;
using System.Collections.Generic;

public class KingdomManager : MonoBehaviour
{
    readonly List<GameObject> objects = new List<GameObject>();
    public Transform kingdomRoot;

    public void BuildKingdom()
    {
        if (kingdomRoot != null) Destroy(kingdomRoot.gameObject);
        kingdomRoot = new GameObject("Kingdom").transform;

        // Ground
        MakeCube("Desert", new Vector3(0,-1,0), new Vector3(38,1,26), new Color(0.68f,0.48f,0.25f));

        // Palace
        MakeCube("قصر مملكة الحقيقة", new Vector3(0,2,2), new Vector3(7,5,6), new Color(0.78f,0.68f,0.42f));
        MakeCylinder("PalaceTower", new Vector3(0,5,2), 2.2f, 4f, new Color(0.9f,0.78f,0.42f));

        // Walls and buildings
        for(int i=-1;i<=1;i++)
            MakeCube("Wall", new Vector3(i*10,1,-5), new Vector3(8,3,1), new Color(0.55f,0.38f,0.22f));

        MakeBuilding("Barracks", new Vector3(-11,1,5), new Color(0.25f,0.32f,0.38f));
        MakeBuilding("Farm", new Vector3(11,1,5), new Color(0.25f,0.55f,0.25f));
        MakeBuilding("Market", new Vector3(-11,1,-7), new Color(0.55f,0.35f,0.15f));
        MakeBuilding("Mine", new Vector3(11,1,-7), new Color(0.25f,0.25f,0.3f));

        // Flags
        MakeFlag(new Vector3(-4,5,2));
        MakeFlag(new Vector3(4,5,2));

        // Camera
        var cam = Camera.main;
        if (cam == null)
        {
            var c = new GameObject("Main Camera");
            c.tag = "MainCamera";
            cam = c.AddComponent<Camera>();
        }
        cam.transform.position = new Vector3(0,22,-25);
        cam.transform.rotation = Quaternion.Euler(35,0,0);
        cam.fieldOfView = 55;
        cam.gameObject.AddComponent<CameraOrbit>();
    }

    void MakeBuilding(string name, Vector3 pos, Color color)
    {
        MakeCube(name, pos + Vector3.up*2, new Vector3(5,4,5), color);
        MakeCylinder(name+"Roof", pos + Vector3.up*4.7f, 3.4f, 1.2f, color*0.8f);
    }

    void MakeFlag(Vector3 pos)
    {
        MakeCylinder("FlagPole", pos, .08f, 4, Color.gray);
        MakeCube("BlueBanner", pos + new Vector3(.7f,1.2f,0), new Vector3(1.4f,1.8f,.08f), new Color(.05f,.25f,.65f));
    }

    GameObject MakeCube(string name, Vector3 pos, Vector3 scale, Color color)
    {
        var go = GameObject.CreatePrimitive(PrimitiveType.Cube);
        go.name = name; go.transform.SetParent(kingdomRoot); go.transform.position=pos; go.transform.localScale=scale;
        go.GetComponent<Renderer>().material.color=color; return go;
    }

    GameObject MakeCylinder(string name, Vector3 pos, float radius, float height, Color color)
    {
        var go = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        go.name=name; go.transform.SetParent(kingdomRoot); go.transform.position=pos; go.transform.localScale=new Vector3(radius,height/2f,radius);
        go.GetComponent<Renderer>().material.color=color; return go;
    }

    public void ShowKingdom()
    {
        if (kingdomRoot != null) kingdomRoot.gameObject.SetActive(true);
        Camera.main.transform.position = new Vector3(0,22,-25);
        Camera.main.transform.rotation = Quaternion.Euler(35,0,0);
    }

    public void HideKingdom()
    {
        if (kingdomRoot != null) kingdomRoot.gameObject.SetActive(false);
    }
}
